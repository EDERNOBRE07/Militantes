var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
async function startServer() {
  const app = (0, import_express.default)();
  const rawPort = process.env.PORT || 3e3;
  const PORT = !isNaN(Number(rawPort)) ? Number(rawPort) : rawPort;
  app.use(import_express.default.json({ limit: "25mb" }));
  app.use(import_express.default.urlencoded({ extended: true, limit: "25mb" }));
  const VAULT_FILE_PATH = import_path.default.join(process.cwd(), "data_server_vault.json");
  const sseClients = /* @__PURE__ */ new Set();
  const broadcastRealTimeUpdate = (type, data) => {
    const payload = `data: ${JSON.stringify({ type, data, timestamp: (/* @__PURE__ */ new Date()).toISOString() })}

`;
    for (const client of sseClients) {
      try {
        client.write(payload);
      } catch {
        sseClients.delete(client);
      }
    }
  };
  const readServerVault = () => {
    try {
      if (import_fs.default.existsSync(VAULT_FILE_PATH)) {
        const raw = import_fs.default.readFileSync(VAULT_FILE_PATH, "utf-8");
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error("Error reading server vault file:", e);
    }
    return {};
  };
  const mergeVaultData = (current, incoming) => {
    const result = { ...current };
    for (const [key, incomingValue] of Object.entries(incoming)) {
      if (key.startsWith("_")) continue;
      if (Array.isArray(incomingValue)) {
        const currentArray = Array.isArray(result[key]) ? result[key] : [];
        const itemMap = /* @__PURE__ */ new Map();
        currentArray.forEach((item) => {
          if (item && item.id) {
            itemMap.set(String(item.id), item);
          }
        });
        incomingValue.forEach((incomingItem) => {
          if (incomingItem && incomingItem.id) {
            const idStr = String(incomingItem.id);
            const existingItem = itemMap.get(idStr);
            if (!existingItem) {
              itemMap.set(idStr, incomingItem);
            } else {
              let merged = { ...existingItem, ...incomingItem };
              if (key === "militancia_checkins_v1") {
                const existingPhotos = Array.isArray(existingItem.photos) ? existingItem.photos : [];
                const incomingPhotos = Array.isArray(incomingItem.photos) ? incomingItem.photos : [];
                const finalPhotos = incomingPhotos.length > 0 ? incomingPhotos : existingPhotos;
                merged = {
                  ...existingItem,
                  ...incomingItem,
                  photos: finalPhotos,
                  observations: incomingItem.observations || existingItem.observations || "",
                  latitude: Number(incomingItem.latitude) || Number(existingItem.latitude) || -27.5962,
                  longitude: Number(incomingItem.longitude) || Number(existingItem.longitude) || -48.619,
                  status: incomingItem.status || existingItem.status || "validado",
                  synced: true
                };
              }
              itemMap.set(idStr, merged);
            }
          }
        });
        const mergedList = Array.from(itemMap.values());
        if (key === "militancia_checkins_v1" || key === "militancia_audit_logs_v1" || key === "militancia_notifications_v1") {
          mergedList.sort((a, b) => {
            const timeA = new Date(a.timestamp || a.timestamp_checkin || a.created_at || 0).getTime();
            const timeB = new Date(b.timestamp || b.timestamp_checkin || b.created_at || 0).getTime();
            return timeB - timeA;
          });
        }
        result[key] = mergedList;
      } else if (incomingValue && typeof incomingValue === "object") {
        result[key] = { ...result[key] || {}, ...incomingValue };
      } else if (incomingValue !== void 0) {
        result[key] = incomingValue;
      }
    }
    result._lastServerSavedAt = (/* @__PURE__ */ new Date()).toISOString();
    return result;
  };
  const writeServerVault = (data) => {
    try {
      const current = readServerVault();
      const updated = mergeVaultData(current, data);
      import_fs.default.writeFileSync(VAULT_FILE_PATH, JSON.stringify(updated, null, 2), "utf-8");
      try {
        const publicVaultPath = import_path.default.join(process.cwd(), "public", "api", "data_server_vault.json");
        if (import_fs.default.existsSync(import_path.default.dirname(publicVaultPath))) {
          import_fs.default.writeFileSync(publicVaultPath, JSON.stringify(updated, null, 2), "utf-8");
        }
      } catch {
      }
      return updated;
    } catch (e) {
      console.error("Error writing server vault file:", e);
      return readServerVault();
    }
  };
  app.get("/api/health", (req, res) => {
    const vault = readServerVault();
    res.json({
      status: "ok",
      service: "Milit\xE2ncia S\xE3o Jos\xE9 - SC API",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      city: "S\xE3o Jos\xE9 - Santa Catarina",
      target_mysql: "u844537895_Militantes @ militancia.mastervisionmarketing.com",
      serverVaultKeys: Object.keys(vault),
      port: typeof PORT === "number" ? PORT : "passenger_socket"
    });
  });
  const handleTestHostinger = async (req, res) => {
    const startTime = Date.now();
    const targetUrl = "https://militancia.mastervisionmarketing.com/api/teste_conexao.php";
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e3);
      const response = await fetch(targetUrl, {
        method: "GET",
        headers: { "Accept": "application/json" },
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;
      const data = await response.json().catch(() => ({ status: "active_non_json" }));
      return res.json({
        success: true,
        endpoint: targetUrl,
        latencyMs,
        httpStatus: response.status,
        hostingerData: data,
        message: "Endpoint Hostinger acess\xEDvel com sucesso."
      });
    } catch (error) {
      const latencyMs = Date.now() - startTime;
      const isTimeout = error.name === "AbortError";
      return res.json({
        success: false,
        endpoint: targetUrl,
        latencyMs,
        isTimeout,
        errorType: isTimeout ? "TIMEOUT_6000MS" : "NETWORK_ERROR",
        errorMessage: error.message || "Erro ao conectar no servidor Hostinger.",
        message: "Servidor Hostinger temporariamente indispon\xEDvel. Modo de conting\xEAncia e cofre local ativo.",
        targetDatabase: "u844537895_Militantes"
      });
    }
  };
  app.get("/api/checkin/test-hostinger", handleTestHostinger);
  app.get("/api/teste_conexao.php", handleTestHostinger);
  app.get("/api/sync/stream", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();
    sseClients.add(res);
    res.write(`data: ${JSON.stringify({ type: "connected", message: "SSE Real-Time Sync Active", timestamp: (/* @__PURE__ */ new Date()).toISOString() })}

`);
    const keepAlive = setInterval(() => {
      try {
        res.write(`: heartbeat

`);
      } catch {
        clearInterval(keepAlive);
        sseClients.delete(res);
      }
    }, 15e3);
    req.on("close", () => {
      clearInterval(keepAlive);
      sseClients.delete(res);
    });
  });
  const handleCheckInPost = async (req, res) => {
    const checkInData = req.body;
    const targetUrl = "https://militancia.mastervisionmarketing.com/api/checkin.php";
    if (!checkInData) {
      return res.status(400).json({
        success: false,
        error: "Dados de check-in inv\xE1lidos."
      });
    }
    let savedCheckin = null;
    try {
      const itemData = checkInData.data || checkInData;
      if (itemData && itemData.id) {
        let photosList = [];
        if (Array.isArray(itemData.photos)) {
          photosList = itemData.photos;
        } else if (itemData.fotos_json) {
          try {
            photosList = typeof itemData.fotos_json === "string" ? JSON.parse(itemData.fotos_json) : itemData.fotos_json;
          } catch {
            photosList = [];
          }
        }
        const normalized = {
          id: String(itemData.id),
          militantId: itemData.militantId || itemData.militante_id || "mil-01",
          militantName: itemData.militantName || itemData.militante_nome || "Militante",
          teamId: itemData.teamId || itemData.equipe_id || "team-1787840837258",
          neighborhoodId: itemData.neighborhoodId || itemData.bairro_id || "forquilhinhas",
          neighborhoodName: itemData.neighborhoodName || itemData.bairro_nome || "Forquilhinhas",
          streetName: itemData.streetName || itemData.nome_rua || "Rua Geral",
          houseNumberRange: itemData.houseNumberRange || itemData.faixa_numeracao || "Trecho Geral",
          timestamp: itemData.timestamp || itemData.timestamp_checkin || (/* @__PURE__ */ new Date()).toISOString(),
          latitude: Number(itemData.latitude) || -27.5962,
          longitude: Number(itemData.longitude) || -48.619,
          accuracyMeters: Number(itemData.accuracyMeters || itemData.precisao_gps_metros || 4.2),
          photos: photosList,
          materialsDelivered: itemData.materialsDelivered || {
            santinhos: Number(itemData.qtd_santinhos || 0),
            adesivos: Number(itemData.qtd_adesivos || 0),
            adesivo_bola: Number(itemData.qtd_adesivo_bola || 0),
            adesivo_parachoque: Number(itemData.qtd_adesivo_parachoque || 0),
            colinhas: Number(itemData.qtd_colinhas || 0),
            abordagens: Number(itemData.qtd_abordagens || 0),
            comercio: Number(itemData.qtd_comercio || 0)
          },
          observations: itemData.observations || itemData.observacoes || "",
          status: itemData.status || itemData.status_auditoria || "validado",
          synced: true
        };
        savedCheckin = normalized;
        writeServerVault({
          militancia_checkins_v1: [normalized]
        });
        broadcastRealTimeUpdate("checkin_created", normalized);
      }
    } catch (e) {
      console.error("Server vault checkin save error:", e);
    }
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8e3);
      const hostingerResponse = await fetch(targetUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(checkInData),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (hostingerResponse.ok) {
        const responseData = await hostingerResponse.json().catch(() => null);
        return res.json({
          success: true,
          status: "synced_mysql",
          destination: "Hostinger MySQL + Server Vault",
          message: "Check-in persistido no cofre do servidor e no MySQL da Hostinger.",
          hostingerResponse: responseData,
          checkIn: savedCheckin || checkInData
        });
      } else {
        return res.json({
          success: true,
          status: "synced_local_vault",
          destination: "Cofre Local do Servidor",
          message: "Check-in garantido no cofre do servidor Node.",
          checkIn: savedCheckin || checkInData
        });
      }
    } catch (error) {
      return res.json({
        success: true,
        status: "synced_local_vault",
        destination: "Cofre Local do Servidor (Offline / Timeout)",
        message: "Check-in gravado no cofre em disco com 100% de integridade.",
        checkIn: savedCheckin || checkInData
      });
    }
  };
  app.post("/api/checkin", handleCheckInPost);
  app.post("/api/checkin.php", handleCheckInPost);
  const handleCheckInGet = async (req, res) => {
    const targetUrl = "https://militancia.mastervisionmarketing.com/api/checkin.php";
    const vault = readServerVault();
    const localCheckins = vault["militancia_checkins_v1"] || [];
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e3);
      const hostingerResponse = await fetch(targetUrl, {
        method: "GET",
        headers: { "Accept": "application/json" },
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (hostingerResponse.ok) {
        const data = await hostingerResponse.json();
        const rawRemote = Array.isArray(data.data) ? data.data : Array.isArray(data) ? data : [];
        const remoteCheckins = rawRemote.map((r) => {
          let photos = [];
          if (Array.isArray(r.photos)) photos = r.photos;
          else if (typeof r.fotos_json === "string" && r.fotos_json.trim()) {
            try {
              photos = JSON.parse(r.fotos_json);
            } catch {
            }
          } else if (Array.isArray(r.fotos_json)) photos = r.fotos_json;
          return {
            id: String(r.id),
            militantId: String(r.militantId || r.militante_id || "mil-01"),
            militantName: String(r.militantName || r.militante_nome || "Militante"),
            teamId: String(r.teamId || r.equipe_id || "team-alpha"),
            neighborhoodId: String(r.neighborhoodId || r.bairro_id || "kobrasol"),
            neighborhoodName: String(r.neighborhoodName || r.bairro_nome || "Kobrasol"),
            streetName: String(r.streetName || r.nome_rua || "Rua de Campo"),
            houseNumberRange: String(r.houseNumberRange || r.faixa_numeracao || "Trecho Geral"),
            timestamp: String(r.timestamp || r.timestamp_checkin || (/* @__PURE__ */ new Date()).toISOString()),
            latitude: Number(r.latitude) || -27.5962,
            longitude: Number(r.longitude) || -48.619,
            accuracyMeters: Number(r.accuracyMeters || r.precisao_gps_metros) || 4,
            materialsDelivered: {
              santinhos: Number(r.materialsDelivered?.santinhos ?? r.qtd_santinhos ?? 0),
              adesivos: Number(r.materialsDelivered?.adesivos ?? r.qtd_adesivos ?? 0),
              adesivo_bola: Number(r.materialsDelivered?.adesivo_bola ?? r.qtd_adesivo_bola ?? 0),
              adesivo_parachoque: Number(r.materialsDelivered?.adesivo_parachoque ?? r.qtd_adesivo_parachoque ?? 0),
              colinhas: Number(r.materialsDelivered?.colinhas ?? r.qtd_colinhas ?? 0),
              abordagens: Number(r.materialsDelivered?.abordagens ?? r.qtd_abordagens ?? 0),
              comercio: Number(r.materialsDelivered?.comercio ?? r.qtd_comercio ?? 0)
            },
            photos: Array.isArray(photos) ? photos : [],
            observations: String(r.observations || r.observacoes || ""),
            status: r.status || r.status_auditoria || "validado",
            synced: true
          };
        });
        const mergedMap = /* @__PURE__ */ new Map();
        localCheckins.forEach((c) => {
          if (c && c.id) mergedMap.set(String(c.id), c);
        });
        remoteCheckins.forEach((c) => {
          if (c && c.id) {
            const idStr = String(c.id);
            const exist = mergedMap.get(idStr);
            const finalPhotos = exist?.photos && exist.photos.length > 0 ? exist.photos : c.photos;
            mergedMap.set(idStr, exist ? { ...c, ...exist, photos: finalPhotos } : c);
          }
        });
        const mergedList = Array.from(mergedMap.values());
        return res.json({ status: "success", data: mergedList, count: mergedList.length });
      }
      return res.json({ status: "local_fallback", data: localCheckins });
    } catch {
      return res.json({ status: "local_fallback", data: localCheckins });
    }
  };
  app.get("/api/checkin", handleCheckInGet);
  app.get("/api/checkin.php", handleCheckInGet);
  const handleSyncPost = async (req, res) => {
    const syncData = req.body;
    const targetUrl = "https://militancia.mastervisionmarketing.com/api/sync.php";
    try {
      if (syncData.key && syncData.data !== void 0) {
        writeServerVault({ [syncData.key]: syncData.data });
        broadcastRealTimeUpdate("collection_updated", { key: syncData.key });
      } else if (syncData.collections && typeof syncData.collections === "object") {
        writeServerVault(syncData.collections);
        broadcastRealTimeUpdate("all_collections_updated", { count: Object.keys(syncData.collections).length });
      }
    } catch (err) {
      console.error("Error saving to server disk vault:", err);
    }
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8e3);
      const hostingerResponse = await fetch(targetUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(syncData),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (hostingerResponse.ok) {
        const json = await hostingerResponse.json().catch(() => null);
        return res.json(json || { status: "success", message: "Sincronizado com Hostinger e salvo no cofre local." });
      } else {
        return res.json({ status: "success", message: "Salvo com sucesso no cofre do servidor." });
      }
    } catch {
      return res.json({ status: "success", message: "Salvo com sucesso no cofre permanente do servidor." });
    }
  };
  app.post("/api/sync", handleSyncPost);
  app.post("/api/sync.php", handleSyncPost);
  const handleSyncGet = async (req, res) => {
    const targetUrl = "https://militancia.mastervisionmarketing.com/api/sync.php";
    const serverVault = readServerVault();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e3);
      const hostingerResponse = await fetch(targetUrl, {
        method: "GET",
        headers: { "Accept": "application/json" },
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (hostingerResponse.ok) {
        const json = await hostingerResponse.json();
        if (json.status === "success" && json.data) {
          const combinedData = { ...json.data };
          for (const key of Object.keys(serverVault)) {
            if (key.startsWith("_")) continue;
            if (Array.isArray(serverVault[key]) && Array.isArray(combinedData[key])) {
              const map = /* @__PURE__ */ new Map();
              combinedData[key].forEach((item) => {
                if (item && item.id) map.set(item.id, item);
              });
              serverVault[key].forEach((item) => {
                if (item && item.id) {
                  const existing = map.get(item.id);
                  map.set(item.id, { ...existing, ...item });
                }
              });
              combinedData[key] = Array.from(map.values());
            } else if (serverVault[key]) {
              combinedData[key] = serverVault[key];
            }
          }
          const realMilitants = combinedData["militantes_data"] || combinedData["militancia_militantes_v1"] || combinedData["militancia_militants_v1"] || [];
          if (Array.isArray(realMilitants) && realMilitants.length > 0) {
            combinedData["militantes_data"] = realMilitants;
            combinedData["militancia_militants_v1"] = realMilitants;
            combinedData["militancia_militantes_v1"] = realMilitants;
          }
          const realVans = combinedData["vans_data"] || combinedData["militancia_vans_v1"] || [];
          if (Array.isArray(realVans) && realVans.length > 0) {
            combinedData["vans_data"] = realVans;
            combinedData["militancia_vans_v1"] = realVans;
          }
          try {
            writeServerVault(combinedData);
          } catch {
          }
          return res.json({ status: "success", data: combinedData, source: "merged_vault_hostinger" });
        }
      }
      return res.json({ status: "success", data: serverVault, source: "server_vault" });
    } catch {
      return res.json({ status: "success", data: serverVault, source: "server_vault_fallback" });
    }
  };
  app.get("/api/sync", handleSyncGet);
  app.get("/api/sync.php", handleSyncGet);
  app.post("/api/ai-strategy", async (req, res) => {
    try {
      const { prompt, contextData } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.json({
          strategy: generateFallbackStrategy(prompt, contextData),
          source: "local_heuristic_advisor"
        });
      }
      const ai = new import_genai.GoogleGenAI({ apiKey });
      const systemInstruction = `Voc\xEA \xE9 o Estrategista-Chefe de Campanha e Coordena\xE7\xE3o Territorial para a elei\xE7\xE3o no munic\xEDpio de S\xE3o Jos\xE9 - SC (Santa Catarina).
Voc\xEA conhece profundamente a geografia, bairros e dados demogr\xE1ficos do Censo IBGE de S\xE3o Jos\xE9:
- Regi\xE3o Central/Campinas: Kobrasol (alto fluxo comercial, edif\xEDcios residenciais), Campinas (Av. Pres. Kennedy, Av. Central), Praia Comprida (hist\xF3rico, hospital regional), Fazenda Santo Ant\xF4nio, Ro\xE7ado.
- Regi\xE3o Barreiros: Barreiros (Av. Leoberto Leal, densamente povoado, divisa com Fpolis), Bela Vista, Serraria, Ipiranga, Areias / Bosque das Mans\xF5es.
- Regi\xE3o Forquilhinhas: Forquilhinhas (grande polo residencial e eleitoral), Forquilhas, Potecas.
- Regi\xE3o Oeste/Sede Rural: Picadas do Sul, Sert\xE3o do Maruim, Col\xF4nia Santana.

A campanha decorre de 26/08/2026 a 03/10/2026 (v\xE9spera da vota\xE7\xE3o).
Os materiais a serem distribu\xEDdos em cada rua s\xE3o: Santinhos, Adesivos, Adesivo Bola (vidro traseiro), Adesivo Parachoque e Colinhas.
Forne\xE7a sempre orienta\xE7\xF5es t\xE1ticas, distribui\xE7\xE3o eficiente de equipes e vans, foco em hor\xE1rios de pico comercial ou residencial, e mensagens motivadoras em Portugu\xEAs do Brasil de forma estruturada e profissional.`;
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            role: "user",
            parts: [
              {
                text: `${systemInstruction}

Contexto Atual da Campanha:
${JSON.stringify(contextData || {}, null, 2)}

Pergunta/Solicita\xE7\xE3o do Coordenador Geral:
${prompt}`
              }
            ]
          }
        ]
      });
      res.json({
        strategy: response.text || "An\xE1lise de cobertura conclu\xEDda com sucesso.",
        source: "gemini-2.5-flash"
      });
    } catch (error) {
      console.error("Gemini API Error:", error);
      res.json({
        strategy: generateFallbackStrategy(req.body?.prompt, req.body?.contextData),
        source: "local_heuristic_advisor_fallback",
        errorNote: error.message
      });
    }
  });
  function generateFallbackStrategy(prompt, context) {
    return `### Plano Estrat\xE9gico de Cobertura Territorial - S\xE3o Jos\xE9 (SC)

**1. Diagn\xF3stico de Cobertura Atual:**
- **Kobrasol & Campinas:** Grande concentra\xE7\xE3o eleitoral. Recomenda-se manter duplas de militantes na Av. L\xE9dio Jo\xE3o Martins e Av. Presidente Kennedy entre 09h e 13h (hor\xE1rio comercial) e foco em adesiva\xE7\xE3o de ve\xEDculos (Adesivo Bola Perfurite).
- **Forquilhinhas & Forquilhas:** Maior densidade de eleitores da Zona Oeste. Priorizar panfletagem porta a porta nas vias transversais \xE0 Rua Vereador Arthur Mariano.
- **Barreiros & Serraria:** Cobertura de 60%. Acelerar a rota da Van 02 no eixo da Av. Leoberto Leal e no loteamento Luar da Serraria.

**2. Aloca\xE7\xE3o T\xE1tica da Frota de Vans:**
- **Van 01 (Sprinter):** Foco matutino em Forquilhinhas e transbordo para Potecas \xE0s 14h.
- **Van 02 (Master):** Eixo Barreiros - Bela Vista - Serraria. Ponto de encontro: Trevo de Barreiros.
- **Van 03 (Ducato):** Sede hist\xF3rica, Praia Comprida e Sert\xE3o do Maruim.

**3. Meta de Materiais para a Pr\xF3xima Rodada:**
- Distribui\xE7\xE3o m\xEDnima de 400 santinhos + 250 colinhas por militante/dia.
- Incentivar registro fotogr\xE1fico com geolocaliza\xE7\xE3o no app de campo para valida\xE7\xE3o imediata no painel.`;
  }
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const candidateDirs = [
      import_path.default.join(process.cwd(), "dist"),
      import_path.default.join(__dirname, "..", "dist"),
      import_path.default.join(__dirname, "dist"),
      process.cwd()
    ];
    const resolvedDist = candidateDirs.find((dir) => import_fs.default.existsSync(import_path.default.join(dir, "index.html"))) || import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(resolvedDist));
    app.get("*", (req, res) => {
      const indexFile = import_path.default.join(resolvedDist, "index.html");
      if (import_fs.default.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(200).send(`<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Milit\xE2ncia S\xE3o Jos\xE9 - SC</title>
</head>
<body style="font-family:sans-serif;background:#0f172a;color:#f8fafc;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
  <div style="background:#1e293b;padding:32px;border-radius:12px;text-align:center;">
    <h2 style="color:#38bdf8;">Sistema de Milit\xE2ncia S\xE3o Jos\xE9 / SC</h2>
    <p style="color:#94a3b8;">Servidor Node.js operacional. Execute o build para carregar o painel.</p>
  </div>
</body>
</html>`);
      }
    });
  }
  if (typeof PORT === "number") {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`[Milit\xE2ncia SJ Server] Running on http://localhost:${PORT}`);
    });
  } else {
    app.listen(PORT, () => {
      console.log(`[Milit\xE2ncia SJ Server] Running on socket: ${PORT}`);
    });
  }
}
startServer();
//# sourceMappingURL=server.cjs.map
